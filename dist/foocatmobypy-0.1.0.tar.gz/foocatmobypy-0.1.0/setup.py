# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['foocatmobypy']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.0.1,<2.0.0']

setup_kwargs = {
    'name': 'foocatmobypy',
    'version': '0.1.0',
    'description': 'Toy package',
    'long_description': None,
    'author': 'Chimaobi Amadi',
    'author_email': 'maobiamadi@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
